<?php
/**
 * Plugin Name: Content Navigator
 * Description: Adds a sticky, collapsible Table of Contents on the left-middle of blog posts.
 * Version: 1.0.0
 * Author: Vishal Verma
 * Text Domain: content-navigator
 */

// Security check
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('CONTENT_NAVIGATOR_VERSION', '1.0.0');
define('CONTENT_NAVIGATOR_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('CONTENT_NAVIGATOR_PLUGIN_URL', plugin_dir_url(__FILE__));

// Check minimum WordPress version
function content_navigator_check_wp_version() {
    if (version_compare(get_bloginfo('version'), '5.0', '<')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(__('Content Navigator requires WordPress 5.0 or higher.', 'content-navigator'));
    }
}
register_activation_hook(__FILE__, 'content_navigator_check_wp_version');

// Load text domain
function content_navigator_load_textdomain() {
    load_plugin_textdomain('content-navigator', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
add_action('plugins_loaded', 'content_navigator_load_textdomain');

// Enqueue CSS & JS
function content_navigator_enqueue_assets() {
    // Only on single blog posts
    if (is_single() && get_post_type() === 'post') {
        wp_enqueue_style(
            'content-navigator-style',
            CONTENT_NAVIGATOR_PLUGIN_URL . 'assets/css/toc-style.css',
            array(),
            CONTENT_NAVIGATOR_VERSION
        );
        
        wp_enqueue_script(
            'content-navigator-script',
            CONTENT_NAVIGATOR_PLUGIN_URL . 'assets/js/toc-script.js',
            array('jquery'),
            CONTENT_NAVIGATOR_VERSION,
            true
        );
    }
}
add_action('wp_enqueue_scripts', 'content_navigator_enqueue_assets');

// Inject the TOC container
function content_navigator_add_container($content) {
    // Only on single blog posts
    if (is_single() && get_post_type() === 'post') {
        $toc = '<div id="sticky-toc">
                  <div id="toc-toggle">' . esc_html__('INDEX', 'content-navigator') . '</div>
                  <div id="toc-inner">
                    <ul id="toc-list"></ul>
                  </div>
                </div>';
        return $toc . $content;
    }
    return $content;
}
add_filter('the_content', 'content_navigator_add_container');

// Add settings link to plugins page
function content_navigator_plugin_action_links($links) {
    $settings_link = '<a href="' . admin_url('options-general.php?page=content-navigator-settings') . '">' . 
                    esc_html__('Settings', 'content-navigator') . '</a>';
    array_unshift($links, $settings_link);
    return $links;
}
add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'content_navigator_plugin_action_links');

// Cleanup on uninstall
function content_navigator_uninstall() {
    // Add any cleanup code here if needed
}
register_uninstall_hook(__FILE__, 'content_navigator_uninstall');