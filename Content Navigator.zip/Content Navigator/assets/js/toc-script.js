document.addEventListener("DOMContentLoaded", function () {
    // Get the content elements
    const content = document.querySelector(".entry-content, .post-content, .article-content, .main-content-area, article, .content-area");
    const tocList = document.getElementById("toc-list");
    const tocInner = document.getElementById("toc-inner");
    const tocToggle = document.getElementById("toc-toggle");
    const stickyToc = document.getElementById("sticky-toc");
    
    // Debug logging
    console.log('TOC Elements:', {
        content: content,
        tocList: tocList,
        tocInner: tocInner,
        tocToggle: tocToggle,
        stickyToc: stickyToc
    });
    
    if (!content || !tocList || !tocToggle || !tocInner) {
        console.log('Required elements not found');
        return;
    }
    
    // Get all heading elements within the content
    const headings = content.querySelectorAll("h2, h3, h4");
    console.log('Found headings:', headings.length);
    
    if (headings.length < 2) {
        console.log('Not enough headings, hiding TOC');
        if (stickyToc) stickyToc.style.display = "none";
        return;
    }
    
    // Build TOC
    headings.forEach((heading, index) => {
        const tagName = heading.tagName.toLowerCase();
        if (!heading.id) heading.id = "toc-heading-" + index;
        const link = document.createElement("a");
        link.href = "#" + heading.id;
        link.textContent = heading.textContent;
        const listItem = document.createElement("li");
        listItem.classList.add(`toc-${tagName}`);
        listItem.appendChild(link);
        tocList.appendChild(listItem);
    });
    
    // Smooth scroll behavior
    document.querySelectorAll('#toc-list a').forEach(link => {
        link.addEventListener("click", function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute("href"));
            if (target) {
                // Get header height for offset if there's a fixed header
                const possibleHeader = document.querySelector('header, .site-header, .main-header');
                let headerOffset = 0;
                
                if (possibleHeader && window.getComputedStyle(possibleHeader).position === 'fixed') {
                    headerOffset = possibleHeader.offsetHeight;
                }
                
                window.scrollTo({
                    top: target.offsetTop - headerOffset - 20,
                    behavior: 'smooth'
                });
                
                // Close the TOC after clicking a link
                tocInner.classList.remove("toc-open");
            }
        });
    });
    
    // Toggle TOC on click
    tocToggle.addEventListener("click", function (e) {
        console.log('Toggle clicked');
        e.preventDefault();
        e.stopPropagation();
        tocInner.classList.toggle("toc-open");
        console.log('TOC state:', tocInner.classList.contains('toc-open'));
    });
    
    // Close TOC when clicking outside
    document.addEventListener('click', function(e) {
        if (tocInner.classList.contains('toc-open') && 
            !tocInner.contains(e.target) && 
            e.target !== tocToggle) {
            console.log('Closing TOC - clicked outside');
            tocInner.classList.remove('toc-open');
        }
    });
    
    // Improved Scrollspy
    window.addEventListener("scroll", function () {
        let scrollPos = window.scrollY || window.pageYOffset;
        let currentSection = null;
        
        // Find the current section
        Array.from(headings).reverse().forEach((heading) => {
            if (heading.offsetTop <= scrollPos + 100) {
                currentSection = heading.id;
                return;
            }
        });
        
        // Update active class
        document.querySelectorAll('#toc-list a').forEach(link => {
            const href = link.getAttribute("href").substring(1); // Remove the #
            if (href === currentSection) {
                link.classList.add("active");
            } else {
                link.classList.remove("active");
            }
        });
    });
    
    // Trigger a scroll event to initialize the active states
    window.dispatchEvent(new Event('scroll'));
});